﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace holamundoCadenas
{
    class Program
    {
        static void Main(string[] args)
        {
            string cadena1 = string.Empty;
            string cadena2 = string.Empty;
            string resultado = string.Empty;

            Console.WriteLine("Escriba para ver si las cadenas son iguales");
            cadena1 = "Amin";

            cadena2 = Console.ReadLine();

            Console.WriteLine("\t\t   SENTENCIA TERNARIA");
            resultado = (cadena1 == cadena2) ? "Las cadenas coinciden" : "Las cadenas no coinciden";
            Console.WriteLine("\t\t" +resultado);

            Console.WriteLine("\n\t\t     Condicion \"if\"");
            if (cadena1 == cadena2)
            {
                Console.WriteLine("\t\tLas cadenas coinciden\n");
            }
            else
            {
                Console.WriteLine("\t\tNo coinciden las cadenas\n");
            }

            Main(null);
            Console.ReadKey();

        }
    }
}
