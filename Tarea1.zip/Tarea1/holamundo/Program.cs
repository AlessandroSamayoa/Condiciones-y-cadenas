﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace holamundo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Escriba el primer número");
            //string primerNumero = Console.ReadLine();
            //Console.WriteLine("Escriba el segundo número");
            //string segundoNumero = Console.ReadLine();

            //int resultado = int.Parse(primerNumero) + Convert.ToInt16(segundoNumero);
            double suma, resta, division, multiplicacion, numero1, numero2;
            int tipoOperacion = 0;
            Console.WriteLine("Escoga que operacion desea realizar");
            Console.WriteLine("1.Suma\n2.Resta\n3.Multiplicación\n4.División");
            tipoOperacion = int.Parse(Console.ReadLine());

            Console.WriteLine("Escriba el primer número");
            numero1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba el segundo número");
            numero2 = double.Parse(Console.ReadLine());
            
            if (tipoOperacion == 1)
            {
                Console.WriteLine("Escogio la suma");
                suma = numero1 + numero2;
                Console.WriteLine("La suma de los números es: " + suma);
                
            }
            else if(tipoOperacion == 2)
            {
                Console.WriteLine("Escogio la resta");
                resta = numero1 - numero2;
                Console.WriteLine("La resta de los números es: " + resta);
                
            }
            else if (tipoOperacion == 3)
            {
                Console.WriteLine("Escogio la multiplicación" );
                multiplicacion = numero1 * numero2;
                Console.WriteLine("La multiplicación de los números es: " + multiplicacion);
                
            }
            else if (tipoOperacion == 4)
            {
                Console.WriteLine("Escogio la división");
                division = numero1 / numero2;
                Console.WriteLine("La división de los números es: " + division);
                
            }
            else
            {
                Console.WriteLine("Dato incorrecto");
                
            }

            Console.WriteLine("Presiona cualquier tecla para reintentar\n");
            Console.ReadKey();
            Main(null);

            //if (resultado >= 50)
            //    Console.WriteLine("El número es mayor a 50");
            //else
            //    Console.WriteLine("El número es menor a 50");

            //string result = "\nEl resultado de la operacion es: ";
            //Console.WriteLine(result + resultado);

            //Console.ReadKey();   
        }
        
    }
}
